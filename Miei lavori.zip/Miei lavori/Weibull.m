% Parametri della distribuzione di Weibull
scale = 2; % Parametro di scala (lambda)
shape = 1.5; % Parametro di forma (k)

% Numero totale di punti da generare
num_points = 1000;

% Tempo di visualizzazione tra i punti (in secondi)
pause_time = 0.001; % Modifica questo valore per controllare la velocit�

% Figura per il plot
figure;
hold on;
xlabel('x');
ylabel('y');
title('Generazione progressiva di punti densit� di Weibull');
grid on;

% Calcolo e plot progressivo
for i = 1:num_points
    % Genera un valore x dalla distribuzione di Weibull
    x = wblrnd(scale, shape); 
    
    % Calcola la densit� di probabilit� f(x)
    fx = wblpdf(x, scale, shape); 
    
    % Genera un valore y casuale nell'intervallo [0, f(x)]
    y = rand * fx;
    
    % Aggiungi il punto (x, y) al grafico
    scatter(x, y, 10, 'filled', 'b'); % Punto blu, dimensione 10
    drawnow; % Aggiorna il grafico per visualizzare il nuovo punto
    
    % Pausa per controllare la velocit� di visualizzazione
    pause(pause_time);
end

% Disegna la curva di densit� di Weibull per confronto
x_vals = linspace(0, 6, 1000); % Valori x per tracciare la curva
f_vals = wblpdf(x_vals, scale, shape); % Valori della densit� di Weibull
plot(x_vals, f_vals, 'r-', 'LineWidth', 1.5); % Curva in rosso

hold off;
