% Parametri
lambda = 0.5; % Tasso della distribuzione esponenziale
num_samples = 1500; % Numero di campioni da generare
pause_time = 0.0001; % Tempo di pausa tra i fotogrammi dell'animazione

% Preallocazione dell'array per i campioni
samples = zeros(num_samples, 1);

% Creazione della figura
figure;
hold on;

% Imposta gli assi
x = linspace(0, 10, 100); % Asse x per la funzione di densit�
pdf = lambda * exp(-lambda * x); % PDF della distribuzione esponenziale
axis([0 10 0 1]); % Limiti degli assi
xlabel('x');
ylabel('Densit� di probabilit�');
title('Simulazione Monte Carlo di una Distribuzione Esponenziale');

% Plotta la PDF
%plot(x, pdf, 'r', 'LineWidth', 2, 'DisplayName', 'PDF'); % PDF in rosso
%legend show;

% Ciclo di animazione
for i = 1:num_samples
    % Genera un campione dalla distribuzione esponenziale
    samples(i) = exprnd(1/lambda);
    
    % Plotta il campione corrente come punto
    %plot(samples(i), 0, 'ko', 'MarkerSize', 8); % Punto blu sulla linea x=0
    
    % Ricalcola l'istogramma dei campioni
    histogram(samples(1:i), 'Normalization', 'pdf', 'BinWidth', 0.5, 'FaceColor', 'b', 'EdgeColor', 'k', 'FaceAlpha', 0.3);
    
    % Aggiungi un titolo dinamico
    title(sprintf('Campioni: %d', i));
    
    % Pausa per l'animazione
    pause(pause_time);
end

hold off;
